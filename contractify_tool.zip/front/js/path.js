var get_client = "./../back/api/client/get.php";
var get_service = "./../back/api/service/get.php";
var get_legal = "./../back/api/service/get_legal.php";
var create_contract = "./../back/api/contract/create.php";
var read_all = "./../back/api/contract/read_all.php";
var delete_contract = "./../back/api/contract/delete.php";
var read = "./../back/api/contract/read.php";
var update_contract = "./../back/api/contract/update.php";